package exam01;

public class Ex01 {
    public static void main(String[] args) {
        int num; // 변수 선언, 값을 담을 수 있는 공간(메모리) 할당
        num = 10; // = (대입 연산자), 오른쪽에 있는 10이라는 값을 왼쪽 변수 num 공간에 저장(대입)

        int num2 = 20; // 변수 선언과 동시에 초기화 - 초기화 : 변수에 최초로 값을 저장 하는 것

        System.out.println(num2);
    }
}
