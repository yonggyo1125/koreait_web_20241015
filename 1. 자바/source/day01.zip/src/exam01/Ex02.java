package exam01;

public class Ex02 {
    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        int numOfStudent;
    }
}
